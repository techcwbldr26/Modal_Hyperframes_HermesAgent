# AGENTS.md — AI Agent Guide for HyperFrames Video Generation

This guide provides instructions, architectural rules, workflow patterns, and battle-tested gotcha solutions for AI coding agents (LLMs) generating agent-native motion graphics videos using **HyperFrames** (`heygen-com/hyperframes`), HTML, CSS, and GSAP.

---

## 🎯 Executive Overview

HyperFrames is a framework for **Video as Code**. It allows an AI agent to build deterministic, programmatic MP4 video compositions using web technologies (HTML, CSS, JavaScript, GSAP). 

When given a request to generate a video based on a **YouTube URL**, **documents (.pdf, .docx, .md)**, or **topic notes**, follow the systematic agent workflow detailed below.

---

## 🛠️ Step-by-Step AI Agent Workflow

### Phase 1: Knowledge Extraction & Script Generation
1. **Source Content Analysis**:
   - Extract raw text from documents (`.pdf`, `.docx`, `.md`) using standard tools (e.g. `textutil`, `pypdf`, `python-docx`, `pandoc`).
   - Summarize YouTube videos by extracting title, transcript, description, or key technical takeaways.
2. **Pedagogical Structuring**:
   - Divide content into **distinct, well-timed scene clips** (e.g., Intro/Title, Paradigm 1, Paradigm 2, ..., Applied Hybrid System Architecture, Outro).
   - Ensure the pacing is **natural and instructional** (slower pacing, clear titles, readable bullet points, syntax-highlighted code snippets).
   - Do NOT clutter a single screen with too much text—split content across sequential, readable clips.

### Phase 2: Visual Style & Design System Engineering
1. **Reference Video Aesthetics (e.g., DeepSeek Harness Explainer)**:
   - **Backdrop**: Dark tech theme (`#090d16` slate gradient) with subtle ambient glow circles and subtle grid line overlays.
   - **Typography**: Dual font hierarchy (`Inter` for headers/body, `JetBrains Mono` for badges, code, and metrics).
   - **Containers**: Translucent glassmorphism cards (`background: rgba(22, 27, 38, 0.85); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.1);`).
   - **Color System**: High-contrast electric accents (Cyan `#38bdf8`, Emerald `#3fb950`, Amber `#d29922`, Ruby `#f85149`, Purple `#a371f7`).
   - **Motion Graphics**: Modular "brick-snapping" diagram nodes, glowing SVG connectors, kinetic text reveals, syntax-highlighted code blocks, and timeline progress bars.

### Phase 3: Composition Structure ("Rule of Three")
HyperFrames requires strict adherence to 3 core structural rules:

```html
<!-- 1. ROOT ELEMENT: Defines global composition metadata -->
<div id="root" 
     data-composition-id="when-to-use-ai" 
     data-width="1920" 
     data-height="1080" 
     data-start="0" 
     data-duration="225">

  <!-- 2. TIMED CLIP ELEMENTS: Timed scenes with class="clip" -->
  <div id="clip-1" class="clip" data-start="0" data-duration="25" data-track-index="1">
    <!-- Scene Content -->
  </div>

  <div id="clip-2" class="clip" data-start="25" data-duration="40" data-track-index="1">
    <!-- Scene Content -->
  </div>
</div>
```

```js
// 3. GSAP TIMELINE REGISTRATION: Must be initialized with { paused: true }
window.__timelines = window.__timelines || {};

const tl = gsap.timeline({ paused: true });

// Build sequenced scene animations...

// Register globally under the exact same composition ID as data-composition-id
window.__timelines["when-to-use-ai"] = tl;
```

---

## ⚠️ Critical Gotchas, Pitfalls & Solutions

| Issue / Gotcha | Root Cause | Solution for AI Agent |
|---|---|---|
| **Render Error: `Not a directory: index.html`** | Passing `index.html` directly to `npx hyperframes render index.html` | **ALWAYS** pass the project directory path (`.`), e.g.: `npx hyperframes render . -o output.mp4` |
| **`FFmpeg / FFprobe not found`** | System PATH lacks `ffmpeg` or `ffprobe` binaries | Download static pre-compiled binaries to project root (`evermeet.cx` on macOS or `@ffmpeg-installer/ffmpeg`) and prepend to PATH: `export PATH="$(pwd):$PATH"` |
| **Blank / Dark Screen on `localhost:8080`** | GSAP timeline is `{ paused: true }` for HyperFrames frame-seeking engine | Add standalone browser auto-play fallback to `anim.js`: `if (!window.location.search.includes('hyperframes') && !window.__HYPERFRAMES__) { tl.play(); }` |
| **Export Error (503) in HyperFrames Studio** | Studio export button invoked with file target instead of folder | Use the CLI render command directly: `npx hyperframes render . -o output.mp4` |
| **Audio Lint Warning / Failures** | Untimed `<audio>` element or missing audio file path | Ensure audio files exist in `assets/`, or add `data-start="0"` attributes. Remove unused `<audio>` tags before rendering. |

---

## 📋 Agent Quality Check Protocol

Before declaring a video composition ready for rendering:
1. Verify `data-composition-id` in `index.html` **EXACTLY matches** `window.__timelines["<id>"]` in `anim.js`.
2. Confirm GSAP timeline is initialized with `{ paused: true }`.
3. Check that total `data-duration` on `#root` matches the sum of clip timelines.
4. Ensure `styles/main.css` has `width: 1920px; height: 1080px; overflow: hidden;` on body and `#root`.
5. Run verification test: `python3 -c "import os; ..."` to validate HTML/CSS/JS syntax.
